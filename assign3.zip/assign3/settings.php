<?php
    $host = "feenix-mariadb.swin.edu.au";
    $user = "s101635296"; // your user name
    $pwd = "050698"; // your password (date of birth ddmmyy unless changed)
    $sql_db = "s101635296_db"; // your database name
?>