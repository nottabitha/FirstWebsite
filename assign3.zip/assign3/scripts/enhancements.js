/**
* Author: Tabitha Leimonis
* Target: enquire.html, payment.html
* Purpose: 
* Created: 15 April 2017
* Last updated: 22 April 2017
* Credits: 
*/

"use strict"

//enhancement 1
function changeWindows() {
    window.location = "index.php";
}
setTimeout(function(){ 
    alert("You have ran out of time, you will be redirected\n"); 
changeWindows();
}, 120000);

//enhancement 2


    



